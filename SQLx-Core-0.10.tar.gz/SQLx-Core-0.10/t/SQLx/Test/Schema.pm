package SQLx::Test::Schema;

use base 'SQLx::Core';

__PACKAGE__->load_namespaces;

1;
