package SQLx::Test::Schema::ResultSet::Foo;

use base 'SQLx::Core';

sub table { 'foo'; }

1;
